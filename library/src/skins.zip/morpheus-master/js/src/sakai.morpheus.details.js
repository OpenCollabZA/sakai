/**
 * For <details> support in FF and IE
 */

$PBJQ('details').details();