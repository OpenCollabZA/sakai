/**
 * For inline Chat in Morpheus: 
 */
 $PBJQ('#footerAppPresence').on("click", function() {
 	$PBJQ('#presenceArea').toggleClass('is-hidden');
 });